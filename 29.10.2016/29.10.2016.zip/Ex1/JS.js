var integerNumber = 123;
var floatingNumber = 1.23;
var booleanType = true;
var text = 'Hello Worold';
var objectType = new Object();
var undefValue;
var nullValue = null;
var arrays = ['first', 'second', 'third'];

document.writeln('1.Integer number = ' + integerNumber + "<br>");
document.writeln('2.Floating-point = ' + floatingNumber + "<br>");
document.writeln('3.Boolean = ' + booleanType + "<br>");
document.writeln('4.Object = ' + objectType + "<br>");
document.writeln('5.Undefined = ' + undefValue + "<br>");
document.writeln('6.Null valu e= ' + nullValue + "<br>");
document.writeln('7.String = ' + text + "<br>");
document.writeln('8.Array = ' + arrays + "<br>");


console.log('1.Integer number = ' + integerNumber);
console.log('2.Floating-point = ' + floatingNumber);
console.log('3.Boolean = ' + booleanType);
console.log('4.Object = ' + objectType);
console.log('5.Undefined = ' + undefValue);
console.log('6.Null valu e= ' + nullValue);
console.log('7.String = ' + text);
console.log('8.Array = ' + arrays);