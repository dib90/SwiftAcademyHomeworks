var a;
console.log(typeof a);
a = 13;
console.log(typeof a);
a = true;
console.log(typeof a);
a = {};
console.log(typeof a);
a = "Hello World";
console.log(typeof a)
a = function (){}
console.log(typeof a);