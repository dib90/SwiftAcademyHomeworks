var undefValue;
var nullValue = null;

document.writeln('1.Undefined = ' + undefValue + ' is type of ' + typeof undefValue + "<br>");
document.writeln('2.Null value = ' + nullValue + ' is type of ' + typeof nullValue + "<br>");

console.log('1.Undefined = ' + undefValue + ' is type of ' + typeof undefValue);
console.log('2.Null value = ' + nullValue + ' is type of ' + typeof nullValue);